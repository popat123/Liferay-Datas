create index IX_986710B0 on rf_Gallery (gallryImagPriority);
create index IX_7F277427 on rf_Gallery (videosImagPriority);
create index IX_59ABDDAA on rf_Gallery (videosImagPriority, gallryImagPriority);