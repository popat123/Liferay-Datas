package com.proliferay.demo.portlet;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.ProcessAction;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.model.CompanyConstants;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.util.bridges.mvc.MVCPortlet;

public class UpdatePortlet extends MVCPortlet{
	
	
	@ProcessAction(name="updatePassword")
	public void updatePassword(ActionRequest actionRequest, ActionResponse actionResponse){
		ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		_log.info(":::::::::::::calling updatePassword::::::::::::::::");
		String current = ParamUtil.getString(actionRequest, "current","");
		String password1 = ParamUtil.getString(actionRequest, "password1","");
		String password2 = ParamUtil.getString(actionRequest, "password2",""); 
		String errorKey = "";
		
		
		 try {
			String authType = themeDisplay.getCompany().getAuthType();
			String login = "";
			/**
			 * authType can be of three types.
			 * Therefore based on authType login can email address or 
			 * screen name or user id of the logged in user
			 */
			if(authType.equals(CompanyConstants.AUTH_TYPE_EA)){
				login = themeDisplay.getUser().getEmailAddress();
			}else if(authType.equals(CompanyConstants.AUTH_TYPE_SN)){
				login = themeDisplay.getUser().getScreenName();
			}else if(authType.equals(CompanyConstants.AUTH_TYPE_ID)){
				login = String.valueOf(themeDisplay.getUser().getUserId());
			}
			
			/**
			 * The method authenticateForBasic returns userId of the logged in user if all 
			 * the parameters in the method are correct. Otherwise it will return 0.
			 * Notice the if condition 
			 */
			
			long userId=UserLocalServiceUtil.authenticateForBasic(themeDisplay.getCompanyId(), authType, login, current);
			if(themeDisplay.getUserId()!=userId)
			{
				errorKey = "invalid-current-password";
				throw new Exception("Invalid current password.");
			}
			if(!password1.equals(password2))
			{
				errorKey = "confirm-new-password";
				throw new Exception("Please confirm new password.");
			}
			UserLocalServiceUtil.updatePassword(userId, password1, password2, false);
			
		} catch (PortalException e) {
			_log.error(e.getMessage(), e);
		} catch (SystemException e) {
			_log.error(e.getMessage(), e);
		} catch (Exception e) {
			_log.error(e.getMessage(), e);
		}		
		
		
		if(Validator.isNull(errorKey)){
			SessionMessages.add(actionRequest, "password-update-success");
		}else{
			SessionErrors.add(actionRequest, errorKey); 
		}
		
		
		
	}
	
	private Log _log = LogFactoryUtil.getLog(UpdatePortlet.class.getName());

}
