package com.jio.portlet.jurys.helper;

public interface JurysPortletConstants {
	
	public static final String JurysId="jurysId";
	public static final String Name="name";
	public static final String Jury_Images="juryImage";
	public static final String Jury_Image_Folder="juryImages";
	public static final String Company_Name="companyName";
	public static final String Category="category";
	public static final String Short_Description="shortDescription";
	public static final String Long_Description="longDescription";
	public static final String Number="number";

}
