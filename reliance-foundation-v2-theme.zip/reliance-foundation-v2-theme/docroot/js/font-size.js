
var min=16;
var max=18;
function increaseFontSize() {
var div = document.getElementsByTagName('div');
for(i=0;i<div.length;i++) {
if(div[i].style.fontSize) {
var s = parseInt(div[i].style.fontSize.replace("px",""));
} else {
var s = 16;
}
if(s!=max) {
s += 1;
}
div[i].style.fontSize = s+"px"
}
}
function decreaseFontSize() {
var div = document.getElementsByTagName('div');
for(i=0;i<div.length;i++) {
if(div[i].style.fontSize) {
var s = parseInt(div[i].style.fontSize.replace("px",""));
} else {
var s = 14;
}
if(s!=min) {
s -= 1;
}
div[i].style.fontSize = s+"px"
}   
}
